#ifndef KMERCOUNT_H
#define KMERCOUNT_H
#include "config.h"

int kmerCountMain(int argc, char** argv);
void parseKmerCountOptions(int argc, char** argv);

#endif
